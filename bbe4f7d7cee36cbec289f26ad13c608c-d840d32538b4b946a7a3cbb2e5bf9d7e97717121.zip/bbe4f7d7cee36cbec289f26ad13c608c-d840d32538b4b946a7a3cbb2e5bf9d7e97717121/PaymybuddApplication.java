package com.mybuddy.paymybudd;


import com.mybuddy.paymybudd.model.Connection;
import com.mybuddy.paymybudd.model.Transaction;
import com.mybuddy.paymybudd.model.User;
import com.mybuddy.paymybudd.service.ConnectionService;
import com.mybuddy.paymybudd.service.TransactionService;
import com.mybuddy.paymybudd.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.Optional;


@SpringBootApplication
public class PaymybuddApplication  implements CommandLineRunner {


	@Autowired
	private UserService userService;

	@Autowired
	private TransactionService transactionService;

	@Autowired
	private ConnectionService connectionService;

	public static void main(String[] args) {
		SpringApplication.run(PaymybuddApplication.class, args);
		}

	@Override
	public void run(String... args) throws Exception {
		Iterable<User> users = userService.getUsers();
		users.forEach(user -> System.out.println(user.getFirstName()));
	}
	  {
		Iterable<Transaction> transactions = transactionService.getTransaction();
		transactions.forEach(transaction -> System.out.println(transaction.getTransactionNumber()));
	}

	{
		Iterable<Connection> connections = connectionService.getConnections();
        connections.forEach(connection -> System.out.println(connection.getId()));

		Optional<User> optUser = userService.getUserById(1);
		User userId1 = optUser.get();
		System.out.println(userId1.getFirstName());

		Optional<Transaction> optTransaction = transactionService.getTransactionById(1);
		Transaction transactionId1 = optTransaction.get();
		System.out.println(transactionId1.getTransactionNumber());

		Optional<Connection> optConnection = connectionService.getConnectionById(1);
		Connection connectionId1 = optConnection.get();
		System.out.println(connectionId1.getId());



	}


}
